import java.sql.Date;
import java.util.List;

public class Vendas {

	public static void setNome(String nome) {
		// TODO Auto-generated method stub
		
	}

	public static void setApelido(String apelido) {
		// TODO Auto-generated method stub
		
	}

	public static void setDtNascimento(Date formatarData) {
		// TODO Auto-generated method stub
		
	}

	public void setId(long id) {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("rawtypes")
	public List findContatos() {
		// TODO Auto-generated method stub
		return null;
	}

	public void alterar(Vendas contato) {
		// TODO Auto-generated method stub
		
	}

	public void salvar(String vendas) {
		// TODO Auto-generated method stub
		
	}

	public void excluir(long id) {
		// TODO Auto-generated method stub
		
	}

	public Container findByName(String nome) {
		// TODO Auto-generated method stub
		return null;
	}

}
