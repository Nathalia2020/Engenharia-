package jdk.internal.platform;

public class Container {

}
