

import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class ContatoController {

    private static final String Vendas = null;

	private Date formatarData(String data) throws ParseException {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return new Date( formatter.parse(data).getTime() );
    }

    public void salvar(String nome, String apelido, String dtNascimento) 
		throws SQLException, ParseException 
	{
    	
        new Vendas().salvar(Vendas);
    }

    @SuppressWarnings("static-access")
	public void alterar(long id, String nome, String apelido, String dtNascimento) 
		throws ParseException, SQLException 
	{
        
    	Vendas contato = new Vendas();
        contato.setId(id);
        contato.setNome(nome);
        contato.setApelido(apelido);
        contato.setDtNascimento(formatarData(dtNascimento));

        new Vendas().alterar(contato);
    }

    @SuppressWarnings("rawtypes")
	public List listaContatos() {
    	Vendas dao = new Vendas();
        return dao.findContatos();
    }

    public void excluir(long id) throws SQLException {
        new Vendas().excluir(id);
    }

    public Container buscaContatoPorNome(String nome) throws SQLException {
    	Vendas dao = new Vendas();
        return dao.findByName(nome);
    }
}